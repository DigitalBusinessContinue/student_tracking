package com.example.projecttrainning.`class`

class Student
{
    var id: String = ""
        get() = field
        set(value) {
            field = value
        }

    var email: String = ""
        get() = field
        set(value) {
            field = value
        }

    var name: String = ""
        get() = field
        set(value) {
            field = value
        }

    var surname: String = ""
        get() = field
        set(value) {
            field = value
        }

    var studentid: String = ""
        get() = field
        set(value) {
            field = value
        }

    var tel: String = ""
        get() = field
        set(value) {
            field = value
        }

    var position: String = ""
        get() = field
        set(value) {
            field = value
        }

    var company: String = ""
        get() = field
        set(value) {
            field = value
        }

    var salary: String = ""
        get() = field
        set(value) {
            field = value
        }
    var status: String = ""
        get() = field
        set(value) {
            field = value
        }


    var trainer: String = ""
        get() = field
        set(value) {
            field = value
        }

    var trainerposition: String = ""
        get() = field
        set(value) {
            field = value
        }

    var trainertel: String = ""
        get() = field
        set(value) {
            field = value
        }

    var trainercompany: String = ""
        get() = field
        set(value) {
            field = value
        }

    var traineraddress: String = ""
        get() = field
        set(value) {
            field = value
        }


    var trainerservice: String = ""
        get() = field
        set(value) {
            field = value
        }

    var image: String = ""
        get() = field
        set(value) {
            field = value
        }



    fun printInfo() {
        println("ID: $id")
        println("Image: $image")
        println("Name: $name $surname")
        println("Student ID: $studentid")
        println("Phone: $tel")
        println("Email: $email")
        println("Company: $company")
        println("Position: $position")
        println("Salary: $salary")


        println("Trainer: $trainer $trainerposition")
        println("Trainer Tel: $trainertel")
        println("Trainer Company: $trainercompany")
        println("Trainer Address: $traineraddress")
        println("Trainer Service: $trainerservice")
        println("Stauts: $status")

    }
}