package com.example.projecttrainning.test

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.example.projecttrainning.R
import com.example.projecttrainning.`class`.Student
import com.example.projecttrainning.databinding.ActivityAddstudentBinding
import com.example.projecttrainning.databinding.ActivityMainBinding
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener


class AddstudentActivity : AppCompatActivity() {
    private lateinit var binding: ActivityAddstudentBinding
    val database = FirebaseDatabase.getInstance()
    val studentRef = database.getReference("students")
    private var studentEmail:String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddstudentBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        studentEmail = intent.getStringExtra("studentEmail").toString()
        Toast.makeText(baseContext, "Student Email:$studentEmail",
            Toast.LENGTH_SHORT).show()


        binding.btnAdd.setOnClickListener {
            val newStudentRef = studentRef.push()
            var tempstr = ""
            val student = Student()
            student.id = newStudentRef.key!!.toString()

            student.email = binding.edtEmail.text.toString()
            student.name = binding.edtName.text.toString()
            student.surname = binding.edtSurname.text.toString()
            student.studentid = binding.edtStudentid.text.toString()
            student.tel = binding.edtTel.text.toString()
            student.position = binding.edtStudentposition.text.toString()
            student.company = binding.edtTrainercompany.text.toString()
            student.traineraddress = binding.edtAddress.text.toString()
            student.trainer = binding.edtTrainer.text.toString()
            student.trainerposition = binding.edtTrainerposition.text.toString()
            student.trainertel = binding.edtTrainnertel.text.toString()
            student.image = binding.edtImage.text.toString()
            newStudentRef.setValue(student)

            finish()
            startActivity(intent)
        }

//        studentRef.addValueEventListener(object : ValueEventListener {
//            override fun onDataChange(dataSnapshot: DataSnapshot) {
//                for (studentSnapshot in dataSnapshot.children) {
//                    val student = studentSnapshot.getValue(Student::class.java)
//                    println(student!!.name)
//                }
//            }
//
//            override fun onCancelled(error: DatabaseError) {
//                println("Error reading data: $error")
//            }
//        })

//        val email = "johndoe@example.com"
//        val query = studentRef.orderByChild("studentemail").equalTo(email)
//
//        query.addValueEventListener(object : ValueEventListener {
//            override fun onDataChange(dataSnapshot: DataSnapshot) {
//                for (studentSnapshot in dataSnapshot.children) {
//                    val student = studentSnapshot.getValue(Student::class.java)
//                    println("Student found: $student")
//                }
//            }
//
//            override fun onCancelled(error: DatabaseError) {
//                println("Error querying data: $error")
//            }
//        })
    }
}