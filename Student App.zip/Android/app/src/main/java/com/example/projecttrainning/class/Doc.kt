package com.example.projecttrainning.`class`

class Doc
{
    var id: String = ""
        get() = field
        set(value) {
            field = value
        }

    var docid: String = ""
        get() = field
        set(value) {
            field = value
        }

    var name: String = ""
        get() = field
        set(value) {
            field = value
        }

    var link: String = ""
        get() = field
        set(value) {
            field = value
        }


}